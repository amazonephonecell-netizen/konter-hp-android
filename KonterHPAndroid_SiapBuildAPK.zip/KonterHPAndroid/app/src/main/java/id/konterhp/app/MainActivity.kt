package id.konterhp.app

import android.content.Context
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = ShopDatabase.get(this).dao()
        setContent { MaterialTheme { KonterApp(dao) } }
    }
}

@Composable
fun KonterApp(dao: ShopDao) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var loggedIn by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("pemilik") }
    var role by remember { mutableStateOf("PEMILIK") }
    var loginName by remember { mutableStateOf("pemilik") }
    var loginPass by remember { mutableStateOf("123456") }
    var loginError by remember { mutableStateOf("") }
    var firstRun by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf("Ringkasan") }
    val stock by dao.stock().collectAsState(initial = emptyList())
    val sales by dao.sales().collectAsState(initial = emptyList())
    val debts by dao.debts().collectAsState(initial = emptyList())
    val expenses by dao.expenses().collectAsState(initial = emptyList())

    LaunchedEffect(Unit) {
        if (dao.user("pemilik") == null) {
            dao.insertUser(User(username = "pemilik", passwordHash = hashPassword("123456"), role = "PEMILIK"))
            dao.insertUser(User(username = "karyawan", passwordHash = hashPassword("123456"), role = "KARYAWAN"))
        }
    }

    if (!loggedIn) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("Konter HP Manager", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Pencatatan offline untuk toko HP", modifier = Modifier.padding(bottom = 20.dp))
            OutlinedTextField(loginName, { loginName = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(loginPass, { loginPass = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())
            if (loginError.isNotBlank()) Text(loginError, color = MaterialTheme.colorScheme.error)
            Button(onClick = {
                scope.launch {
                    val u = dao.user(loginName.trim())
                    if (u != null && u.passwordHash == hashPassword(loginPass)) {
                        username = u.username; role = u.role; loggedIn = true; loginError = ""
                    } else loginError = "Username atau password salah"
                }
            }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Text("Masuk") }
            Spacer(Modifier.height(12.dp))
            Text("Login awal: pemilik / 123456  •  karyawan / 123456", style = MaterialTheme.typography.bodySmall)
            Text("Ganti kata sandi default setelah login dengan mengubah akun pada pengembangan berikutnya.", style = MaterialTheme.typography.bodySmall)
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBarCompat(title = "Konter HP • $username", onLogout = { loggedIn = false })
        },
        bottomBar = {
            NavigationBar {
                listOf("Ringkasan", "Stok", "Penjualan", "Utang", "Laporan").forEach {
                    NavigationBarItem(selected = tab == it, onClick = { tab = it }, label = { Text(it) }, icon = {})
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 14.dp)) {
            when (tab) {
                "Ringkasan" -> Dashboard(stock.size, sales, expenses)
                "Stok" -> StockScreen(dao, stock, role)
                "Penjualan" -> SalesScreen(dao, stock, sales, role, context)
                "Utang" -> DebtScreen(dao, debts, role)
                "Laporan" -> ReportScreen(dao, sales, expenses, role)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarCompat(title: String, onLogout: () -> Unit) {
    TopAppBar(title = { Text(title) }, actions = {
        TextButton(onClick = onLogout) { Text("Keluar") }
    })
}

fun rupiah(n: Long): String = "Rp " + String.format(Locale("id", "ID"), "%,d", n).replace(',', '.')
fun dateText(t: Long): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID")).format(Date(t))

@Composable
fun Dashboard(stockCount: Int, sales: List<Sale>, expenses: List<Expense>) {
    val omzet = sales.sumOf { it.salePrice }
    val laba = sales.sumOf { it.salePrice - it.costPrice }
    val piutang = sales.sumOf { (it.salePrice - it.paid).coerceAtLeast(0) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 16.dp)) {
        Text("Ringkasan usaha", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Metric("Stok tersedia", "$stockCount unit")
        Metric("Omzet tercatat", rupiah(omzet))
        Metric("Laba kotor", rupiah(laba))
        Metric("Pengeluaran", rupiah(expenses.sumOf { it.amount }))
        Metric("Piutang pelanggan", rupiah(piutang))
        Text("Laba bersih estimasi: ${rupiah(laba - expenses.sumOf { it.amount })}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
        Text("Laporan dihitung dari semua transaksi tersimpan.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun Metric(label: String, value: String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun StockScreen(dao: ShopDao, stock: List<Phone>, role: String) {
    val scope = rememberCoroutineScope()
    var brand by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var condition by remember { mutableStateOf("Bekas") }
    var imei by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Text("Tambah stok HP", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
            OutlinedTextField(brand, { brand = it }, label = { Text("Merek") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(model, { model = it }, label = { Text("Model / tipe") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(condition, { condition = it }, label = { Text("Kondisi: Baru/Bekas") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(imei, { imei = it }, label = { Text("IMEI (unik)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(cost, { cost = it }, label = { Text("Harga modal (angka)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(price, { price = it }, label = { Text("Harga jual (angka)") }, modifier = Modifier.fillMaxWidth())
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error)
            Button(enabled = role == "PEMILIK" && brand.isNotBlank() && model.isNotBlank() && imei.isNotBlank() && cost.toLongOrNull() != null && price.toLongOrNull() != null,
                onClick = {
                    scope.launch {
                        try {
                            if (dao.allPhones().any { it.imei == imei.trim() }) message = "IMEI sudah terdaftar"
                            else {
                                dao.insertPhone(Phone(brand = brand.trim(), model = model.trim(), condition = condition.trim(), imei = imei.trim(),
                                    cost = cost.toLong(), price = price.toLong()))
                                brand = ""; model = ""; imei = ""; cost = ""; price = ""; message = ""
                            }
                        } catch (e: Exception) { message = "Gagal menyimpan: periksa IMEI dan nominal" }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (role == "PEMILIK") "Simpan stok" else "Hanya pemilik dapat menambah stok") }
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text("Stok tersedia (${stock.size})", style = MaterialTheme.typography.titleMedium)
        LazyColumn {
            items(stock, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${p.brand} ${p.model}", fontWeight = FontWeight.Bold)
                        Text("IMEI: ${p.imei} • ${p.condition}")
                        Text("Modal ${rupiah(p.cost)} • Jual ${rupiah(p.price)}")
                    }
                }
            }
        }
    }
}

@Composable
fun SalesScreen(dao: ShopDao, stock: List<Phone>, sales: List<Sale>, role: String, context: Context) {
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<Long?>(null) }
    var customer by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("Tunai") }
    var message by remember { mutableStateOf("") }
    val phone = stock.firstOrNull { it.id == selected }
    Column(Modifier.fillMaxSize()) {
        Text("Catat penjualan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (stock.isEmpty()) Text("Belum ada stok. Tambahkan HP di menu Stok.")
        else {
            Text("Pilih unit (IMEI)", modifier = Modifier.padding(top = 8.dp))
            stock.forEach { p ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    RadioButton(selected == p.id, onClick = { selected = p.id; paid = p.price.toString() })
                    Column(Modifier.weight(1f).padding(top = 8.dp)) {
                        Text("${p.brand} ${p.model}")
                        Text("${p.imei} • ${rupiah(p.price)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            OutlinedTextField(customer, { customer = it }, label = { Text("Nama pelanggan") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(paid, { paid = it }, label = { Text("Jumlah dibayar (angka)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(method, { method = it }, label = { Text("Metode: Tunai/Transfer/Kredit") }, modifier = Modifier.fillMaxWidth())
            if (message.isNotBlank()) Text(message)
            Button(enabled = phone != null && paid.toLongOrNull() != null && (paid.toLongOrNull() ?: -1) >= 0 &&
                    (paid.toLongOrNull() ?: Long.MAX_VALUE) <= (phone?.price ?: 0),
                onClick = {
                    scope.launch {
                        val p = phone ?: return@launch
                        val amt = paid.toLong()
                        if (dao.markSold(p.id) == 1) {
                            val sale = Sale(phoneId = p.id, phoneName = "${p.brand} ${p.model}", imei = p.imei,
                                customer = customer.ifBlank { "Pelanggan umum" }, salePrice = p.price, costPrice = p.cost,
                                paid = amt, paymentMethod = method)
                            dao.insertSale(sale)
                            message = "Penjualan tersimpan"
                            selected = null; customer = ""; paid = ""
                        } else message = "Unit sudah terjual atau stok berubah"
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Simpan penjualan") }
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text("Riwayat penjualan", style = MaterialTheme.typography.titleMedium)
        LazyColumn {
            items(sales, key = { it.id }) { s ->
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text(s.phoneName, fontWeight = FontWeight.Bold)
                        Text("${s.customer} • ${dateText(s.createdAt)}")
                        Text("IMEI ${s.imei} • Jual ${rupiah(s.salePrice)} • Bayar ${rupiah(s.paid)}")
                        TextButton(onClick = { printReceipt(context, s) }) { Text("Cetak nota") }
                    }
                }
            }
        }
    }
}

@Composable
fun DebtScreen(dao: ShopDao, debts: List<Sale>, role: String) {
    val scope = rememberCoroutineScope()
    var amounts by remember { mutableStateOf(mapOf<Long, String>()) }
    Column(Modifier.fillMaxSize()) {
        Text("Utang pelanggan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (debts.isEmpty()) Text("Tidak ada piutang aktif.")
        LazyColumn {
            items(debts, key = { it.id }) { s ->
                val remain = s.salePrice - s.paid
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(s.customer, fontWeight = FontWeight.Bold)
                        Text("${s.phoneName} • IMEI ${s.imei}")
                        Text("Sisa utang: ${rupiah(remain)}")
                        if (role == "PEMILIK") {
                            OutlinedTextField(amounts[s.id] ?: "", { amounts = amounts + (s.id to it) },
                                label = { Text("Pembayaran masuk (angka)") }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = {
                                val add = amounts[s.id]?.toLongOrNull() ?: 0
                                if (add > 0 && add <= remain) scope.launch {
                                    dao.updatePaid(s.id, s.paid + add)
                                    amounts = amounts - s.id
                                }
                            }) { Text("Catat pembayaran") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportScreen(dao: ShopDao, sales: List<Sale>, expenses: List<Expense>, role: String) {
    val scope = rememberCoroutineScope()
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    val omzet = sales.sumOf { it.salePrice }
    val modal = sales.sumOf { it.costPrice }
    val expenseTotal = expenses.sumOf { it.amount }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 14.dp)) {
        Text("Laporan laba rugi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Metric("Omzet", rupiah(omzet))
        Metric("Modal barang terjual", rupiah(modal))
        Metric("Laba kotor", rupiah(omzet - modal))
        Metric("Pengeluaran toko", rupiah(expenseTotal))
        Metric("Laba bersih estimasi", rupiah(omzet - modal - expenseTotal))
        Text("Tambah pengeluaran", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
        OutlinedTextField(description, { description = it }, label = { Text("Keterangan") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(amount, { amount = it }, label = { Text("Nominal (angka)") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = role == "PEMILIK" && description.isNotBlank() && (amount.toLongOrNull() ?: 0) > 0,
            onClick = {
                scope.launch { dao.insertExpense(Expense(description = description.trim(), amount = amount.toLong())); description = ""; amount = "" }
            }, modifier = Modifier.fillMaxWidth()) { Text(if (role == "PEMILIK") "Simpan pengeluaran" else "Hanya pemilik dapat mencatat pengeluaran") }
    }
}

fun printReceipt(context: Context, sale: Sale) {
    val web = WebView(context)
    web.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView, url: String) {
            val manager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
            manager.print("Nota-${sale.id}", view.createPrintDocumentAdapter("Nota-${sale.id}"),
                PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build())
        }
    }
    val html = """
        <html><body style="font-family: sans-serif; padding:24px">
        <h2>NOTA PENJUALAN KONTER HP</h2><hr/>
        <p>No. Nota: ${sale.id}</p><p>Tanggal: ${dateText(sale.createdAt)}</p>
        <p>Pelanggan: ${sale.customer}</p><hr/>
        <p>Barang: ${sale.phoneName}</p><p>IMEI: ${sale.imei}</p>
        <p>Harga jual: ${rupiah(sale.salePrice)}</p><p>Dibayar: ${rupiah(sale.paid)}</p>
        <p>Sisa utang: ${rupiah(sale.salePrice - sale.paid)}</p>
        <p>Metode: ${sale.paymentMethod}</p><hr/><p>Terima kasih telah berbelanja.</p>
        </body></html>
    """.trimIndent()
    web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
}
