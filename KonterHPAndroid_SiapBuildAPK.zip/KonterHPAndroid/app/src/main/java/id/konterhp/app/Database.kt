package id.konterhp.app

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "users", indices = [Index(value = ["username"], unique = true)])
data class User(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val passwordHash: String,
    val role: String
)

@Entity(tableName = "phones", indices = [Index(value = ["imei"], unique = true)])
data class Phone(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val brand: String,
    val model: String,
    val condition: String,
    val imei: String,
    val cost: Long,
    val price: Long,
    val status: String = "STOK"
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val phoneId: Long,
    val phoneName: String,
    val imei: String,
    val customer: String,
    val salePrice: Long,
    val costPrice: Long,
    val paid: Long,
    val paymentMethod: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val description: String,
    val amount: Long,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface ShopDao {
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun user(username: String): User?
    @Insert suspend fun insertUser(user: User)
    @Query("SELECT * FROM phones WHERE status = 'STOK' ORDER BY id DESC")
    fun stock(): Flow<List<Phone>>
    @Query("SELECT * FROM phones ORDER BY id DESC")
    suspend fun allPhones(): List<Phone>
    @Insert suspend fun insertPhone(phone: Phone)
    @Query("UPDATE phones SET status = 'TERJUAL' WHERE id = :id AND status = 'STOK'")
    suspend fun markSold(id: Long): Int
    @Query("SELECT * FROM phones WHERE id = :id LIMIT 1")
    suspend fun phone(id: Long): Phone?
    @Insert suspend fun insertSale(sale: Sale)
    @Query("SELECT * FROM sales ORDER BY createdAt DESC")
    fun sales(): Flow<List<Sale>>
    @Query("SELECT * FROM sales ORDER BY createdAt DESC")
    suspend fun allSales(): List<Sale>
    @Query("SELECT * FROM sales WHERE paid < salePrice ORDER BY createdAt DESC")
    fun debts(): Flow<List<Sale>>
    @Insert suspend fun insertExpense(expense: Expense)
    @Query("SELECT * FROM expenses ORDER BY createdAt DESC")
    fun expenses(): Flow<List<Expense>>
    @Query("SELECT * FROM expenses")
    suspend fun allExpenses(): List<Expense>
    @Query("UPDATE sales SET paid = :newPaid WHERE id = :saleId")
    suspend fun updatePaid(saleId: Long, newPaid: Long)
}

@Database(entities = [User::class, Phone::class, Sale::class, Expense::class], version = 1, exportSchema = false)
abstract class ShopDatabase : RoomDatabase() {
    abstract fun dao(): ShopDao
    companion object {
        @Volatile private var INSTANCE: ShopDatabase? = null
        fun get(context: Context): ShopDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, ShopDatabase::class.java, "konter_hp.db")
                .build().also { INSTANCE = it }
        }
    }
}
