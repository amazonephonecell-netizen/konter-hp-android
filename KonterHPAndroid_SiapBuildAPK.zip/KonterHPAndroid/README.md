# Konter HP Manager (Android, offline)

Aplikasi dasar pencatatan konter HP dengan Kotlin, Jetpack Compose, Room/SQLite lokal.

## Fitur
- Login pemilik dan karyawan.
- Data stok per unit dan IMEI unik.
- Pencatatan penjualan dan status stok otomatis menjadi terjual.
- Pencatatan pembayaran sebagian dan daftar piutang.
- Pencatatan pengeluaran.
- Ringkasan omzet, modal barang terjual, laba kotor, pengeluaran, estimasi laba bersih.
- Cetak nota melalui menu print Android.
- Data tersimpan pada database lokal `konter_hp.db`, tidak memerlukan internet.

## Login awal
- Pemilik: `pemilik` / `123456`
- Karyawan: `karyawan` / `123456`

**Penting:** kredensial awal hanya untuk demo. Sebelum penggunaan nyata, ubah implementasi pengelolaan password agar pemilik dapat mengganti kata sandi, dan tambahkan PIN/biometrik jika diperlukan. Versi dasar ini tidak menyediakan layar ubah password.

## Cara membuka dan membangun APK
1. Instal Android Studio versi stabil.
2. Ekstrak ZIP ini.
3. Android Studio → **Open** → pilih folder `KonterHPAndroid` (folder yang berisi `settings.gradle.kts`).
4. Tunggu Gradle Sync selesai. Gunakan JDK 17.
5. Untuk uji coba, sambungkan HP Android dengan USB debugging atau buat emulator.
6. Tekan **Run**.
7. Untuk membuat APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
8. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`. Lokasi aktual akan ditampilkan Android Studio.
9. Pindahkan APK ke HP dan izinkan instalasi dari sumber tersebut bila diminta.

## Catatan penting
- Seluruh data disimpan offline pada perangkat. Menghapus aplikasi dapat menghapus database; lakukan backup perangkat sebelum penggunaan rutin.
- Versi dasar belum mempunyai ekspor/backup database, penggantian password dari UI, penghapusan/koreksi transaksi, atau laporan periode tanggal.
- Hak akses sederhana: karyawan dapat melihat stok dan mencatat penjualan; penambahan stok, pencatatan pembayaran utang, dan pengeluaran dibatasi untuk pemilik.
- Laba bersih estimasi = laba kotor semua transaksi tersimpan dikurangi seluruh pengeluaran tersimpan. Belum difilter per tanggal/periode.
- Cetak nota menggunakan dialog cetak Android dan ukuran A4; printer thermal mungkin perlu aplikasi/driver printer yang sesuai.
- Sebelum dipakai untuk pembukuan resmi, uji data dan lakukan pengembangan lanjutan untuk backup, perubahan password, audit transaksi, serta perlindungan data yang lebih kuat.


## Membuat APK dari HP dengan GitHub Actions
Proyek menyertakan workflow `.github/workflows/build-apk.yml` untuk membuat APK debug di server GitHub.

1. Buat/login akun di https://github.com.
2. Buat repository baru, misalnya `konter-hp-manager`.
3. Upload seluruh isi folder proyek (bukan ZIP sebagai satu file) ke repository. Pastikan `settings.gradle.kts`, `build.gradle.kts`, folder `app`, dan folder `.github` berada di root repository.
4. Buka tab **Actions** di repository dan aktifkan Actions bila diminta.
5. Pilih workflow **Build Konter HP APK**, tekan **Run workflow**.
6. Tunggu sampai selesai dengan tanda hijau. Buka run yang berhasil, lalu unduh artifact **KonterHP-debug-apk**.
7. Ekstrak artifact ZIP; di dalamnya ada `app-debug.apk`. Buka APK di Android dan izinkan instalasi aplikasi dari sumber yang Anda pilih bila diminta.

Jangan pernah membagikan password GitHub atau access token kepada orang lain. Workflow membuat APK debug untuk pengujian, bukan APK rilis Play Store. Build pertama belum dijalankan dari lingkungan ini; jika gagal, buka log Actions dan perbaiki error yang dilaporkan.
